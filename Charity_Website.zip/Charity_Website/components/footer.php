<div class="container-fluid footer">
        <footer>
            <p>Copyright &copy; 2023 CTA Foundation</p>
            <a href="#" class="text-dark">Terms of Use</a>
            <span class="text-muted mx-2">|</span>
            <a href="#" class=" text-dark">Privacy Policy</a>
        </footer>
    </div>